<html>
    <head>
        <title>News</title>
    </head>
    <body>
        News Page
    </body>
</html>