<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Questionnaire extends CI_Controller {

	public function index()
	{
            //echo 'hi';
            $this->load->model('section');
            $data['rs'] = $this->section->get_all();
            $this->load->view('section_view', $data);
	}
        
}
/* End of file questionnaire.php */
/* Location: ./application/modules/questionnaire/controllers/questionnaire.php */